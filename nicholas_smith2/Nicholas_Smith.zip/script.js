var count = 0;
var button = document.querySelector(".rightIcons");
var counter = document.querySelector (".cart");
counter.innerHTML = count;
button.addEventListener("click", function() {
    counter.innerHTML = ++count;
});

function onclick(elem){
    onclick = ()
    elem.src = document.getElementById('leftChev').src
}