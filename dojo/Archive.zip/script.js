function turnOff(element) {
    element.innerText = "Logout";
}
function hide(element) {
    element.remove();
}
